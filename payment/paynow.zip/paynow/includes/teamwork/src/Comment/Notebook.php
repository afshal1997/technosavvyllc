<?php namespace TeamWorkPm\Comment;

class Notebook extends Model
{
    protected $resource = 'notebooks';
}