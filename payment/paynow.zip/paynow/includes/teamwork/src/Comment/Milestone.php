<?php namespace TeamWorkPm\Comment;

class Milestone extends Model
{
    protected $resource = 'milestones';
}