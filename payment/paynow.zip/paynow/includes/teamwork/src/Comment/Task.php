<?php namespace TeamWorkPm\Comment;

class Task extends Model
{
    protected $resource = 'todo_items';
}