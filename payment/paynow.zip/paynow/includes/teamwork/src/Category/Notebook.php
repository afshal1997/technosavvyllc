<?php namespace TeamWorkPm\Category;

class Notebook extends Model
{
}