<?php namespace TeamWorkPm\Category;

class Message extends Model
{
}