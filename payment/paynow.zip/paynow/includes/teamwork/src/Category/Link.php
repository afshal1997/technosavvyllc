<?php namespace TeamWorkPm\Category;

class Link extends Model
{
}
