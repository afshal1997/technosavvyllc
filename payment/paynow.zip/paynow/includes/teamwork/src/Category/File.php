<?php namespace TeamWorkPm\Category;

class File extends Model
{
}